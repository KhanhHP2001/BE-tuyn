import { AuthGuardGuard } from './auth_guard.guard';

describe('AuthGuardGuard', () => {
  it('should be defined', () => {
    expect(new AuthGuardGuard()).toBeDefined();
  });
});
